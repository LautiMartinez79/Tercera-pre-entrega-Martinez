# buloneria/views.py
from django.shortcuts import render

def inicio(request):
    return render(request, 'inicio.html')  # O cualquier otra plantilla

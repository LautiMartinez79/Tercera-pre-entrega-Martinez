# Tercera-Pre-Entrega-Martinez
"""
Hola , este mi proyecto. Desarrolle un programa que sirva para cargar en una base de datos la informacion de clientes, proveedores y  el stock.
PASOS PARA USAR EL PROYECTO:

1.Para iniciar el programa deben cambiar la ruta, que se encuetra en settings.py en ella parte de templates = dirs[]

2.Utilizando el comando "python manage.py createsuperuser" podemos crear un usuario para ingresar dentro de la base de datos y ver toda la informacion

2.1.Luego deben iniciar el debugging e iniciar el server utilizando el comando "python manage.py runserver". 

3.Dentro del server al url le deben agregar "inicio/".

4.En la pantalla de inicio van a aparecer en la parte superior tres modelos para interactuar (cliente, provedores y deposito), dentro de cada uno se puede cargar informacion dependiendo a cuak corresponda.

5.Si cargamos informacion en el modelo deposito, podemos regresar al inicio y en la parte inferior se van a encontrar con un buscador de marcas. Este sirve para ver si dentro de nuestra base de datos se pueden encontrar los item de esas marcas.

5.1 Podemos verificar la base de datos agregando "admin/" al final del url. 



SALUDOS!!!





"""
